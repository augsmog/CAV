# College Football Player Valuation Model

A comprehensive framework for estimating the value of college football players to their programs and in the transfer portal market.

## Overview

This model combines multiple factors to produce detailed valuations:
- **On-field performance** metrics and advanced statistics
- **Scheme fit** analysis for different coaching systems
- **Personal brand and NIL** value estimation
- **Win impact** contribution (WAR calculation)
- **Positional value** based on scarcity and strategic importance
- **Transfer portal market dynamics**

## Project Structure

```
cfb_valuation_model/
├── data/
│   ├── schemas.py              # Data structure definitions
│   ├── raw/                    # Raw input data
│   ├── processed/              # Cleaned and processed data
│   └── historical/             # Historical transfer data
├── models/
│   ├── performance.py          # Performance metrics calculation
│   ├── scheme_fit.py           # Scheme compatibility analysis
│   ├── brand_valuation.py     # NIL and brand value estimation
│   └── valuation_engine.py    # Comprehensive valuation engine
├── analysis/
│   ├── backtesting.py         # Model validation framework
│   └── validation/            # Validation results
├── outputs/
│   ├── reports/               # Generated reports
│   └── visualizations/        # Charts and graphs
├── docs/                      # Additional documentation
└── example_usage.py           # Usage examples
```

## Key Features

### 1. Performance Evaluation
- Position-specific statistical analysis
- Advanced metrics (EPA, success rate, PFF grades)
- Strength of schedule adjustments
- Consistency and clutch performance factors
- Career trajectory analysis

### 2. Scheme Fit Analysis
- Matches player skills to coaching schemes
- Physical requirements assessment
- Learning curve estimation
- Archetype matching (e.g., pocket passer vs dual-threat QB)
- Compares fit across multiple programs

### 3. Brand & NIL Valuation
- Social media presence quantification
- Media coverage analysis
- Marketability scoring
- Market size impact
- Position-specific brand multipliers
- NIL value estimates with confidence intervals

### 4. Win Impact (WAR)
- Wins Above Replacement calculation
- Position importance weighting
- Snap count consideration
- Team context adjustments
- Championship probability impact

### 5. Risk Assessment
- Injury history analysis
- Performance consistency evaluation
- Off-field risk factors
- Overall risk scoring and categorization

### 6. Market Valuation
- Current program value
- Transfer portal market value
- Alternative program comparisons
- Value confidence intervals
- Transfer recommendations

## Installation & Setup

### Requirements
```bash
pip install numpy pandas --break-system-packages
```

### Quick Start
```python
from models.valuation_engine import create_valuation_engine

# Initialize engine
engine = create_valuation_engine()

# Prepare player data (see data/schemas.py for full structure)
player_data = {
    'player_id': 'QB001',
    'name': 'John Smith',
    'position': 'QB',
    'stats': {...},
    'instagram_followers': 125000,
    # ... additional fields
}

# Calculate valuation
valuation = engine.calculate_comprehensive_valuation(
    player_data=player_data,
    current_program='Texas',
    target_programs=['Alabama', 'Georgia', 'USC']
)

# Access results
print(f"Market Value: ${valuation['market_value']:,.0f}")
print(f"NIL Estimate: ${valuation['nil_value_estimate']['annual_expected']:,.0f}")
```

## Usage Examples

### Example 1: Single Player Valuation
```python
python example_usage.py
```

Run the comprehensive example script to see:
- Complete player valuation
- Component score breakdowns
- Alternative program comparisons
- Transfer recommendations

### Example 2: Batch Processing
```python
from models.valuation_engine import create_valuation_engine
import pandas as pd

engine = create_valuation_engine()
players_df = pd.read_csv('data/processed/players.csv')

valuations = []
for _, player in players_df.iterrows():
    val = engine.calculate_comprehensive_valuation(
        player_data=player.to_dict(),
        current_program=player['current_program']
    )
    valuations.append(val)

results_df = pd.DataFrame(valuations)
results_df.to_csv('outputs/valuations.csv', index=False)
```

### Example 3: Transfer Scenario Analysis
```python
# Compare value across different destinations
target_programs = ['Alabama', 'Georgia', 'Ohio State', 'USC', 'Oregon']

valuation = engine.calculate_comprehensive_valuation(
    player_data=player_data,
    current_program=current_program,
    target_programs=target_programs
)

# Review alternative program values
for program, details in valuation['alternative_program_values'].items():
    print(f"{program}: ${details['total_value']:,.0f}")
    print(f"  Scheme Fit: {details['scheme_fit_score']:.1f}")
    print(f"  NIL Potential: ${details['nil_potential']:,.0f}")
```

## Backtesting & Validation

### Running Backtests
```python
from analysis.backtesting import BacktestingFramework
from models.valuation_engine import create_valuation_engine

engine = create_valuation_engine()
backtest = BacktestingFramework(engine)

# Load historical transfer data
historical_transfers = load_transfer_data('data/historical/transfers.csv')
player_data = load_player_data('data/historical/players.csv')

# Run backtest
results_df = backtest.backtest_transfers(
    historical_transfers=historical_transfers,
    historical_player_data=player_data,
    test_period=(date(2023, 1, 1), date(2024, 12, 31))
)

# Calculate accuracy metrics
metrics = backtest.calculate_accuracy_metrics(results_df)
print(f"Mean Absolute Error: ${metrics['mean_absolute_error']:,.0f}")
print(f"Destination Accuracy: {metrics['destination_accuracy']:.1f}%")
```

### Cross-Validation
```python
cv_results = backtest.cross_validate(
    all_transfers=historical_transfers,
    player_data=player_data,
    n_folds=5
)

print(f"Mean MAE across folds: ${cv_results['mean_mae']:,.0f}")
print(f"Mean Destination Accuracy: {cv_results['mean_destination_accuracy']:.1f}%")
```

## Data Requirements

### Required Player Data Fields
- **Biographical**: ID, name, position, height, weight, eligibility
- **Performance**: Season statistics, advanced metrics, snap counts
- **Brand**: Social media followers, engagement rates, media mentions
- **Skills**: Position-specific skill ratings
- **Context**: Current program, conference, team performance

### Optional But Recommended
- Injury history
- Film evaluation grades
- Previous scheme experience
- Known NIL deal values
- Career trajectory data

See `data/schemas.py` for complete data structure definitions.

## Model Components

### Performance Calculator
```python
from models.performance import PerformanceCalculator

calc = PerformanceCalculator()
performance_result = calc.calculate_performance_score(
    player_stats=stats_dict,
    position='QB',
    conference='SEC',
    opponent_strength=1.15
)
```

### Scheme Fit Calculator
```python
from models.scheme_fit import SchemeFitCalculator

fit_calc = SchemeFitCalculator()
fit_result = fit_calc.calculate_scheme_fit(
    player_profile=player_dict,
    scheme_name='Air Raid',
    position='QB'
)
```

### Brand Calculator
```python
from models.brand_valuation import BrandValuationCalculator

brand_calc = BrandValuationCalculator()
brand_result = brand_calc.calculate_brand_score(
    player_profile=player_dict,
    current_program='Texas',
    performance_score=85.0
)
```

## Customization

### Adjusting Model Weights
Edit `models/valuation_engine.py` to modify component weights:

```python
# In _calculate_program_value method
total_value = (
    (base_value + position_value) * fit_multiplier +
    nil_value +
    win_value +
    familiarity_bonus
)

# Adjust these multipliers based on your backtesting results
```

### Adding New Schemes
Edit `models/scheme_fit.py` to add scheme definitions:

```python
'New Scheme Name': {
    'QB': SchemeRequirements(
        scheme_name='New Scheme Name',
        position='QB',
        skill_weights={
            'arm_strength': 8,
            'accuracy_short': 9,
            # ... add more skills
        },
        complexity_level=7
    )
}
```

### Custom Risk Factors
Modify `_calculate_risk_factors` in `models/valuation_engine.py`:

```python
# Add custom risk calculations
custom_risk = calculate_custom_risk(player_data)
total_risk = (injury_risk * 0.4 + 
             performance_risk * 0.3 + 
             off_field_risk * 0.2 +
             custom_risk * 0.1)
```

## Best Practices

### Data Quality
1. **Verify data sources**: Use official statistics when possible
2. **Handle missing data**: Set reasonable defaults for missing values
3. **Update regularly**: Keep player data current, especially social media metrics
4. **Validate inputs**: Check for outliers and data entry errors

### Model Tuning
1. **Start with backtesting**: Validate on historical data before using for predictions
2. **Iterate on weights**: Use optimization to find best component weights
3. **Position-specific tuning**: Different positions may need different weight schemes
4. **Regular recalibration**: Update model as transfer market evolves

### Practical Application
1. **Use confidence intervals**: Don't rely on point estimates alone
2. **Consider context**: Model provides estimates, not guarantees
3. **Combine with scouting**: Use as complement to traditional evaluation
4. **Monitor outcomes**: Track prediction accuracy over time

## Interpretation Guide

### Valuation Outputs

**Market Value Range:**
- <$100k: Depth player, limited transfer appeal
- $100k-$250k: Solid contributor, some transfer interest
- $250k-$500k: Strong starter, multiple transfer options
- $500k-$1M: Elite player, high transfer demand
- >$1M: Premium talent, top programs competing

**Component Scores (0-100):**
- 90-100: Elite
- 80-89: Excellent
- 70-79: Good
- 60-69: Average
- <60: Below average

**Risk Categories:**
- Low Risk: Safe investment, minimal concerns
- Average Risk: Normal considerations
- Elevated Risk: Notable concerns requiring attention
- High Risk: Significant concerns affecting value

## Limitations & Considerations

### Model Limitations
1. **Data dependency**: Accuracy depends on data quality and completeness
2. **Market volatility**: NIL market is evolving and unpredictable
3. **Qualitative factors**: Cannot fully capture intangibles like leadership
4. **Sample size**: Limited historical transfer data for validation
5. **Scheme changes**: Coaching changes can invalidate fit assessments

### Use Case Considerations
1. **Not financial advice**: Estimates are for analysis purposes
2. **Complement other tools**: Use alongside traditional scouting
3. **Context matters**: Consider unique circumstances for each player
4. **Regular updates**: Model needs periodic recalibration

## Future Enhancements

### Planned Features
- [ ] Integration with real-time transfer portal data
- [ ] Machine learning for pattern recognition
- [ ] Automated data collection pipelines
- [ ] Interactive web interface
- [ ] Advanced visualization dashboards
- [ ] Monte Carlo simulation for outcome probabilities
- [ ] Team fit beyond individual scheme analysis
- [ ] Draft projection impact on valuations

### Research Areas
- Peer effects and team chemistry factors
- Geographic/regional loyalty considerations
- Academic requirements impact
- Playing time probability models
- Career development trajectory predictions

## Contributing

This is a framework for building a comprehensive valuation model. To contribute:

1. Test the model with real historical data
2. Identify inaccuracies and biases
3. Propose weight adjustments based on backtesting
4. Add new features or metrics
5. Improve documentation

## Support & Resources

### Key Files
- `example_usage.py` - Start here for examples
- `data/schemas.py` - Data structure reference
- `models/valuation_engine.py` - Main valuation logic

### Getting Help
1. Review the example usage script
2. Check data schemas for required fields
3. Review backtesting results for accuracy
4. Examine individual component calculators

## License & Disclaimer

This model is for educational and analytical purposes. Valuations are estimates based on quantifiable factors and should not be considered definitive or used as the sole basis for financial decisions. The transfer portal market is complex and influenced by many factors beyond this model's scope.

## Version History

**v1.0** - Initial release
- Complete valuation framework
- Performance, scheme fit, brand, and market components
- Backtesting and validation framework
- Example usage and documentation

---

**Model Version:** 1.0  
**Last Updated:** October 2025
